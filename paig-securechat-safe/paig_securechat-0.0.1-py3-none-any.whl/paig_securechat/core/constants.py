MODE: str = "docker"
HOST: str = "0.0.0.0"
PORT: int = 3535
ROOT_DIR: str = None
BASE_ROUTE = "/securechat/api/v1"
SINGLE_USER_MODE: bool = False
DEFAULT_USER_NAME = "PAIG_DEMO_USER"


class RequestType:
    PROMPT = "prompt"
    ENRICHED_PROMPT = "enriched_prompt"
    REPLY = "reply"
    RAG = "rag"
